#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/types.h>

MODULE_DESCRIPTION("Bypass RC Core for Kernel 6.x Closed ROM");
MODULE_LICENSE("GPL");

void *rc_allocate_device(int type);
int rc_register_device(void *dev, struct module *owner);
void rc_unregister_device(void *dev);
void rc_free_device(void *dev);
int rc_keydown(void *dev, int protocol, u32 scancode, u8 toggle);
void rc_keyup(void *dev);

void *rc_allocate_device(int type) { return NULL; }
EXPORT_SYMBOL(rc_allocate_device);

int rc_register_device(void *dev, struct module *owner) {
        pr_info("rc-core-mock: [Kernel 6.x Anti-RC] rc_register_device intercepted safely.\n");
        return 0;
}
EXPORT_SYMBOL(rc_register_device);

void rc_unregister_device(void *dev) {}
EXPORT_SYMBOL(rc_unregister_device);

void rc_free_device(void *dev) {}
EXPORT_SYMBOL(rc_free_device);

int rc_keydown(void *dev, int protocol, u32 scancode, u8 toggle) { return 0; }
EXPORT_SYMBOL(rc_keydown);

void rc_keyup(void *dev) {}
EXPORT_SYMBOL(rc_keyup);
