#include <linux/module.h>
#include <linux/kernel.h>
MODULE_DESCRIPTION("Mock dib7000p");
MODULE_LICENSE("GPL");
void *dib7000p_attach(void *a, u8 b, void *c);
void *dib7000p_attach(void *a, u8 b, void *c) { return a; }
EXPORT_SYMBOL(dib7000p_attach);
