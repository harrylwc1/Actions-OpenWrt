#include <linux/module.h>
#include <linux/kernel.h>
MODULE_DESCRIPTION("Mock mxl5005s");
MODULE_LICENSE("GPL");
void *mxl5005s_attach(void *a, void *b, void *c);
void *mxl5005s_attach(void *a, void *b, void *c) { return a; }
EXPORT_SYMBOL(mxl5005s_attach);
