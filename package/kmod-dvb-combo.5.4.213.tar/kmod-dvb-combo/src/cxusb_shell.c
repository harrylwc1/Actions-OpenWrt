#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/usb.h>
#include <linux/slab.h>

MODULE_DESCRIPTION("Pure Unified DVB USB Framework Shell Skeleton for 5.4.213");
MODULE_LICENSE("GPL");

/* 僅負責導出全域標準函數符號，絕對不包含任何實體 usb_driver 註冊 */
int dvb_usb_device_init(struct usb_interface *intf, void *props, struct module *owner, void *dev, short *adapter_nums) { return 0; }
EXPORT_SYMBOL(dvb_usb_device_init);

void dvb_usb_device_exit(struct usb_interface *intf) {}
EXPORT_SYMBOL(dvb_usb_device_exit);

int dvb_usb_adapter_stream_init(void *adap) { return 0; }
EXPORT_SYMBOL(dvb_usb_adapter_stream_init);

int dvb_usb_adapter_stream_exit(void *adap) { return 0; }
EXPORT_SYMBOL(dvb_usb_adapter_stream_exit);

int dvb_usb_generic_rw(void *d, u8 *wbuf, u16 wlen, u8 *rbuf, u16 rlen, int delay) { return 0; }
EXPORT_SYMBOL(dvb_usb_generic_rw);

void usb_urb_kill(void *stream) {}
EXPORT_SYMBOL(usb_urb_kill);

int usb_urb_submit(void *stream) { return 0; }
EXPORT_SYMBOL(usb_urb_submit);
