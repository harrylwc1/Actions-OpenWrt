#!/usr/bin/ucode

'use strict';

import { readfile, writefile, access, popen } from 'fs';

let path = ARGV[0] || '';
let redir_port = +(ARGV[1] || '7891');
let tproxy_port = +(ARGV[2] || '7982');
let mixed_port = +(ARGV[3] || '7890');
let has_tun_device = (ARGV[4] || '1') == '1';
if (has_tun_device && system('(ip tuntap add mode tun name cotuntest >/dev/null 2>&1 && ip link del cotuntest >/dev/null 2>&1)') != 0)
	has_tun_device = false;

// default 6666 must match fw4.sh CORE_ROUTING_MARK (0x1a0a)
let routing_mark = +(ARGV[5] || '6666');
let dns_port = +(ARGV[6] || '1053');
let dash_port = +(ARGV[7] || '9090');
let dash_secret = ARGV[8] != null ? (ARGV[8] + '') : '';

if (!path) {
	print("missing path\n");
	exit(1);
}

let raw = readfile(path);
if (!raw) {
	print("read failed\n");
	exit(1);
}

let cfg = json(raw);
if (!cfg) {
	print("json parse failed\n");
	exit(1);
}

function s_len(s) {
	return length(s || '');
}

function s_sub(s, start, count) {
	if (count == null)
		return substr(s || '', start);
	return substr(s || '', start, count);
}

function is_space(ch) {
	return ch == ' ' || ch == '\t' || ch == '\r' || ch == '\n';
}

function trim_s(s) {
	s = (s == null) ? '' : (s + '');
	while (s_len(s) > 0 && is_space(s_sub(s, 0, 1)))
		s = s_sub(s, 1);
	while (s_len(s) > 0 && is_space(s_sub(s, s_len(s) - 1, 1)))
		s = s_sub(s, 0, s_len(s) - 1);
	return s;
}

let default_interface = '';
let _default_if_pipe = popen("ip -4 route show default 2>/dev/null | awk '{print $5; exit}'");
if (_default_if_pipe) {
	default_interface = trim_s(_default_if_pipe.read('all'));
	_default_if_pipe.close();
}

function starts_with(s, prefix) {
	return s_sub(s || '', 0, s_len(prefix)) == prefix;
}

function find_char(s, ch) {
	for (let i = 0; i < s_len(s); i++)
		if (s_sub(s, i, 1) == ch)
			return i;
	return -1;
}

function find_last_char(s, ch) {
	for (let i = s_len(s) - 1; i >= 0; i--)
		if (s_sub(s, i, 1) == ch)
			return i;
	return -1;
}

function split_uci_words(line) {
	let out = [], cur = '', quote = '', esc = false;
	for (let i = 0; i < s_len(line); i++) {
		let ch = s_sub(line, i, 1);
		if (esc) {
			cur += ch;
			esc = false;
			continue;
		}
		if (ch == '\\') {
			esc = true;
			continue;
		}
		if (quote) {
			if (ch == quote)
				quote = '';
			else
				cur += ch;
			continue;
		}
		if (ch == '"' || ch == "'") {
			quote = ch;
			continue;
		}
		if (is_space(ch)) {
			if (s_len(cur) > 0) {
				push(out, cur);
				cur = '';
			}
			continue;
		}
		cur += ch;
	}
	if (s_len(cur) > 0)
		push(out, cur);
	return out;
}

function load_clashoo_uci() {
	let uci_path = ARGV[9] || '/etc/config/clashoo';
	let txt = readfile(uci_path) || '';
	let sections = [], cur = null;
	for (let line in split(txt, '\n')) {
		line = trim_s(line);
		if (!s_len(line) || starts_with(line, '#'))
			continue;
		let words = split_uci_words(line);
		if (!length(words))
			continue;
		if (words[0] == 'config') {
			cur = { type: words[1] || '', name: words[2] || '', options: {}, lists: {} };
			push(sections, cur);
			continue;
		}
		if (!cur || length(words) < 3)
			continue;
		if (words[0] == 'option')
			cur.options[words[1]] = words[2];
		else if (words[0] == 'list') {
			if (cur.lists[words[1]] == null)
				cur.lists[words[1]] = [];
			push(cur.lists[words[1]], words[2]);
		}
	}
	return sections;
}

let clashoo_uci = load_clashoo_uci();

function uci_config_section() {
	for (let s in clashoo_uci)
		if (s.type == 'clashoo' && (s.name == 'config' || s.name == ''))
			return s;
	return {};
}

let uci_cfg = uci_config_section();

function uci_opt(key, def) {
	if (uci_cfg.options && uci_cfg.options[key] != null)
		return uci_cfg.options[key];
	return def;
}

function uci_list(key) {
	if (uci_cfg.lists && uci_cfg.lists[key] != null)
		return uci_cfg.lists[key];
	if (uci_cfg.options && uci_cfg.options[key] != null)
		return [ uci_cfg.options[key] ];
	return [];
}

function uci_sections(type_name) {
	let out = [];
	for (let s in clashoo_uci)
		if (s.type == type_name)
			push(out, s);
	return out;
}

function opt_bool(v, def) {
	if (v == null || v == '')
		return def;
	return v === true || v == '1' || v == 'true' || v == 'yes' || v == 'on';
}

function normalize_dns_uri(address, protocol, port) {
	address = trim_s(address || '');
	protocol = trim_s(protocol || '');
	port = trim_s(port || '');
	if (!s_len(address))
		return '';
	if (find_char(address, ':') >= 0 && find_char(address, '/') >= 0)
		return address;
	if (protocol == 'none')
		protocol = '';
	if (protocol == 'dot')
		protocol = 'tls://';
	else if (protocol == 'doh')
		protocol = 'https://';
	else if (protocol == 'doq')
		protocol = 'quic://';
	if (s_len(protocol) && !starts_with(protocol, 'udp://') && !starts_with(protocol, 'tcp://') &&
	    !starts_with(protocol, 'tls://') && !starts_with(protocol, 'https://') && !starts_with(protocol, 'quic://'))
		protocol += '://';
	return protocol + address + (s_len(port) ? ':' + port : '');
}

function direct_outbound_tag() {
	for (let ob in (cfg.outbounds || []))
		if (ob && ob.type == 'direct' && s_len(ob.tag || ''))
			return ob.tag;
	return 'DIRECT';
}

function dns_server_obj(uri, tag, fallback_type) {
	uri = normalize_dns_uri(uri || '', '', '');
	if (!s_len(uri))
		return null;
	let scheme = fallback_type || 'udp';
	let rest = uri;
	let p = -1;
	for (let i = 0; i < s_len(uri) - 2; i++) {
		if (s_sub(uri, i, 3) == '://') {
			p = i;
			break;
		}
	}
	if (p >= 0) {
		scheme = s_sub(uri, 0, p);
		rest = s_sub(uri, p + 3);
	}
	if (scheme == 'dot')
		scheme = 'tls';
	else if (scheme == 'doh')
		scheme = 'https';
	else if (scheme == 'doq')
		scheme = 'quic';

	let path = '';
	let slash = find_char(rest, '/');
	if (slash >= 0) {
		path = s_sub(rest, slash);
		rest = s_sub(rest, 0, slash);
	}

	let server = rest, server_port = null;
	let colon = find_last_char(rest, ':');
	if (colon > 0 && find_char(rest, ']') < 0) {
		server = s_sub(rest, 0, colon);
		let n = +(s_sub(rest, colon + 1));
		if (n === n)
			server_port = n;
	}

	let obj = { type: scheme, tag: tag, server: server };
	if (server_port != null)
		obj.server_port = server_port;
	if (path && (scheme == 'https' || scheme == 'h3'))
		obj.path = path;
	if ((scheme == 'https' || scheme == 'tls' || scheme == 'quic') && tag != 'dns_resolver')
		obj.domain_resolver = 'dns_resolver';
	/* sing-box 1.12+ DNS servers detour to the proxy by default, so a server
	 * resolving its own domain via dns_resolver loops -> "deadline exceeded".
	 * Force direct/resolver servers to DIRECT; only dns_proxy may use the proxy. */
	if (tag == 'dns_resolver' || tag == 'dns_direct' || tag == 'dns_foreign')
		obj.detour = direct_outbound_tag();
	return obj;
}

function dns_servers_by_role(role) {
	let out = [];
	for (let s in uci_sections('dnsservers')) {
		if (!opt_bool(s.options.enabled, true))
			continue;
		if ((s.options.ser_type || 'nameserver') != role)
			continue;
		let uri = normalize_dns_uri(s.options.ser_address || '', s.options.protocol || '', s.options.ser_port || '');
		if (s_len(uri))
			push(out, uri);
	}
	return out;
}

function first_or(arr, fallback) {
	return length(arr) ? arr[0] : fallback;
}

function local_rule_set_path(tag) {
	if (!s_len(tag))
		return '';
	let path = '/usr/share/clashoo/ruleset/' + tag + '.srs';
	if (access(path, 'r'))
		return path;
	if (tag == 'geolocation-cn' || tag == 'cn') {
		path = '/usr/share/clashoo/ruleset/geosite-cn.srs';
		if (access(path, 'r'))
			return path;
	}
	return '';
}

function keep_remote_rule_set(rs) {
	return false;
}

function normalize_rule_set_url(url) {
	url = url || '';
	url = replace(url, /^https:\/\/gh-proxy\.com\//, '');
	let m = match(url, /^https:\/\/raw\.githubusercontent\.com\/([^\/]+)\/([^\/]+)\/([^\/]+)\/(.+)$/);
	if (m)
		return 'https://cdn.jsdelivr.net/gh/' + m[1] + '/' + m[2] + '@' + m[3] + '/' + m[4];
	m = match(url, /^https:\/\/github\.com\/([^\/]+)\/([^\/]+)\/raw\/refs\/heads\/([^\/]+)\/(.+)$/);
	if (m)
		return 'https://cdn.jsdelivr.net/gh/' + m[1] + '/' + m[2] + '@' + m[3] + '/' + m[4];
	return url;
}

function has_route_rule_set(tag) {
	for (let rs in (cfg.route || {}).rule_set || [])
		if (rs && rs.tag == tag)
			return true;
	return false;
}

function add_remote_rule_set(tag, url) {
	cfg.route = cfg.route || {};
	cfg.route.rule_set = cfg.route.rule_set || [];
	if (has_route_rule_set(tag))
		return;
	push(cfg.route.rule_set, {
		tag: tag,
		type: 'remote',
		format: 'binary',
		url: url
	});
}

function array_has_value(arr, val) {
	if (type(arr) != 'array')
		return false;
	for (let item in arr)
		if (item == val)
			return true;
	return false;
}

let dnsmasq_uid = null;
let _dnsmasq_uid_pipe = popen("id -u dnsmasq 2>/dev/null");
if (_dnsmasq_uid_pipe) {
	let value = trim_s(_dnsmasq_uid_pipe.read('all'));
	_dnsmasq_uid_pipe.close();
	if (match(value, /^[0-9]+$/))
		dnsmasq_uid = +value;
}

function ensure_tun_dnsmasq_exclude(ib) {
	if (dnsmasq_uid == null)
		return;
	let excludes = ib.exclude_uid;
	if (type(excludes) != 'array')
		excludes = excludes != null ? [ excludes ] : [];
	if (!array_has_value(excludes, dnsmasq_uid))
		push(excludes, dnsmasq_uid);
	ib.exclude_uid = excludes;
}

function ensure_tun_cn_exclude(ib) {
	let excludes = ib.route_exclude_address_set;
	if (type(excludes) != 'array')
		excludes = excludes ? [ excludes ] : [];
	if (!array_has_value(excludes, 'cn-ip'))
		push(excludes, 'cn-ip');
	ib.route_exclude_address_set = excludes;
}

function prune_tun_cn_exclude_if_missing() {
	if (has_route_rule_set('cn-ip'))
		return;
	for (let ib in cfg.inbounds || []) {
		if (!ib || ib.type != 'tun')
			continue;
		let excludes = [];
		for (let item in ib.route_exclude_address_set || [])
			if (item != 'cn-ip')
				push(excludes, item);
		if (length(excludes))
			ib.route_exclude_address_set = excludes;
		else
			delete ib.route_exclude_address_set;
	}
}

function matcher_rule(matcher, server_tag) {
	let r = { server: server_tag };
	if (starts_with(matcher, 'geosite:'))
		r.rule_set = s_sub(matcher, 8);
	else if (starts_with(matcher, 'rule_set:'))
		r.rule_set = s_sub(matcher, 9);
	else if (starts_with(matcher, 'domain:'))
		r.domain = s_sub(matcher, 7);
	else if (starts_with(matcher, 'domain-suffix:'))
		r.domain_suffix = s_sub(matcher, 14);
	else
		r.domain_suffix = matcher;
	return r;
}

function apply_dns_from_uci() {
	cfg.dns = cfg.dns || {};
	/* strip mihomo-style DNS fields (enable/ipv6/listen/fake-ip-filter/nameserver...)
	 * that leak in from YAML conversion; sing-box rejects them (Fatal). */
	let _mihomo_dns_fields = ['enable', 'ipv6', 'listen', 'fake-ip-filter', 'fake-ip-range',
	                'enhanced-mode', 'nameserver', 'fallback', 'fallback-filter',
	                'use-hosts', 'default-nameserver', 'proxy-server-nameserver',
	                'direct-nameserver', 'nameserver-policy'];
	for (let _i = 0; _i < length(_mihomo_dns_fields); _i++)
		delete cfg.dns[_mihomo_dns_fields[_i]];
	/* strip mihomo-style experimental fields */
	let _mihomo_exp = ['sniff-tls-sni', 'sniff', 'sniffer'];
	for (let _me = 0; _me < length(_mihomo_exp); _me++)
		if (cfg.experimental && cfg.experimental[_mihomo_exp[_me]] != null)
			delete cfg.experimental[_mihomo_exp[_me]];
	/* strip non-sing-box root-level fields */
	let _mihomo_root = ['clash-for-android', 'cfw-bypass', 'sniffer', 'profile',
	                'geodata-mode', 'geodata-loader', 'geox-url', 'geo-auto-update',
	                'geo-update-interval', 'tun', 'ipv6', 'interface-name',
	                'port', 'socks-port', 'mixed-port', 'redir-port', 'tproxy-port', 'mode', 'allow-lan', 'log-level', 'external-controller', 'secret', 'bind-address', 'routing-mark', 'find-process-mode', 'tcp-concurrent', 'unified-delay',
	                'keep-alive-interval', 'keep-alive-idle', 'disable-keep-alive'];
	/* strip subconverter note fields and non-standard keys */
	let _subconv_fields = ['_note', '_sub_url', 'hosts', 'script', 'enable', 'fake-ip-filter', 'fake-ip-range'];
	for (let _sf = 0; _sf < length(_subconv_fields); _sf++)
		if (cfg[_subconv_fields[_sf]] != null)
			delete cfg[_subconv_fields[_sf]];
	for (let _mr = 0; _mr < length(_mihomo_root); _mr++)
		if (cfg[_mihomo_root[_mr]] != null)
			delete cfg[_mihomo_root[_mr]];
	let bootstrap = uci_list('default_nameserver');
	if (!length(bootstrap))
		bootstrap = uci_list('defaul_nameserver');
	let resolver_uri = first_or(bootstrap, '223.5.5.5');
	let direct_uri = first_or(dns_servers_by_role('direct-nameserver'), first_or(dns_servers_by_role('proxy-server-nameserver'), 'https://doh.pub/dns-query'));
	let proxy_uri = first_or(dns_servers_by_role('nameserver'), first_or(dns_servers_by_role('fallback'), 'https://1.1.1.1/dns-query'));

	let servers = [];
	push(servers, dns_server_obj(resolver_uri, 'dns_resolver', 'udp'));
	push(servers, dns_server_obj(direct_uri, 'dns_direct', 'udp'));
	push(servers, dns_server_obj(proxy_uri, 'dns_proxy', 'tls'));

	let enhanced = uci_opt('enhanced_mode', 'fake-ip');
	if (enhanced == 'fake-ip') {
		let fake_range = uci_opt('fake_ip_range', '198.18.0.1/16');
		push(servers, {
			type: 'fakeip',
			tag: 'dns_fakeip',
			inet4_range: fake_range || '198.18.0.1/16',
			inet6_range: 'fc00::/18'
		});
	}

	let rules = [];
	push(servers, { type: 'udp', tag: 'dns_foreign', server: '1.1.1.1' });
		if (enhanced == 'fake-ip') {
			push(rules, {
				rule_set: 'geolocation-!cn',
				server: 'dns_fakeip'
			});
		}

	let clean_servers = [];
	for (let s in servers)
		if (s)
			push(clean_servers, s);
	cfg.dns.servers = clean_servers;
	cfg.dns.rules = rules;

	/* Keep bootstrap direct; proxy unmatched queries in strict mode. */
	if (opt_bool(uci_opt('dns_leak_protect', '0'), false)) {
		cfg.dns.final = 'dns_proxy';
		if (!opt_bool(uci_opt('ipv6_proxy', '0'), false))
			unshift(cfg.dns.rules, { query_type: ['AAAA'], action: 'reject', method: 'drop' });
	} else
		cfg.dns.final = 'dns_direct';

	let ecs = trim_s(uci_opt('dns_ecs', ''));
	if (s_len(ecs))
		cfg.dns.client_subnet = ecs;
	else
		delete cfg.dns.client_subnet;

	if (opt_bool(uci_opt('singbox_independent_cache', '0'), false))
		cfg.dns.independent_cache = true;
	else
		delete cfg.dns.independent_cache;

		/* sing-box 1.14 requires this (else Fatal); dns_resolver is DIRECT so first-start node lookups use direct DNS */
		cfg.route.default_domain_resolver = 'dns_resolver';
	}

let inbounds = cfg.inbounds || [];
let normalized = [];
let has_redirect = false;
let has_tproxy = false;
let has_mixed = false;
let has_tun = false;
let has_dns_in = false;
let wants_tun = has_tun_device && (uci_opt('tcp_mode', '') == 'tun' || uci_opt('udp_mode', '') == 'tun');
let tun_stack = uci_opt('stack', 'mixed') || 'mixed';

if (wants_tun) {
	add_remote_rule_set('cn-ip',
		'https://github.com/MetaCubeX/meta-rules-dat/raw/refs/heads/sing/geo/geoip/cn.srs');
}

for (let ib in inbounds) {
	if (!ib)
		continue;

	if (ib.type == 'tun' || ib.tag == 'tun-in') {
		/* Keep tun inbound only when the selected proxy mode actually uses TUN. */
		if (wants_tun && !has_tun) {
			ib.type = 'tun';
			ib.tag = ib.tag || 'tun-in';
			if (!ib.address)
				ib.address = [ '172.19.0.1/30', 'fdfe:dcba:9876::1/126' ];
			ib.auto_route = true;
			ib.auto_redirect = true;
			ib.auto_redirect_input_mark = '0x2023';
			ib.auto_redirect_output_mark = '0x2024';
			ib.strict_route = true;
			ib.stack = tun_stack;
			ensure_tun_dnsmasq_exclude(ib);
			ensure_tun_cn_exclude(ib);
			push(normalized, ib);
			has_tun = true;
		}
		continue;
	}

	if (ib.tag == 'redirect-in' || ib.type == 'redirect') {
		if (has_redirect)
			continue;
		ib.type = 'redirect';
		ib.tag = 'redirect-in';
		ib.listen = '0.0.0.0';
		ib.listen_port = redir_port;
		has_redirect = true;
		push(normalized, ib);
		continue;
	}

	if (ib.tag == 'tproxy-in' || ib.type == 'tproxy') {
		if (has_tproxy)
			continue;
		ib.type = 'tproxy';
		ib.tag = 'tproxy-in';
		ib.listen = '0.0.0.0';
		ib.listen_port = tproxy_port;
		ib.network = 'udp';
		has_tproxy = true;
		push(normalized, ib);
		continue;
	}

	if (ib.tag == 'mixed-in' || ib.type == 'mixed') {
		if (has_mixed)
			continue;
		ib.type = 'mixed';
		ib.tag = 'mixed-in';
		ib.listen = '0.0.0.0';
		ib.listen_port = mixed_port;
		has_mixed = true;
		push(normalized, ib);
		continue;
	}

	if (ib.tag == 'dns-in') {
		if (has_dns_in)
			continue;
		ib.type = 'direct';
		ib.tag = 'dns-in';
		ib.listen = '0.0.0.0';
		ib.listen_port = dns_port;
		has_dns_in = true;
		push(normalized, ib);
		continue;
	}

	push(normalized, ib);
}

if (!has_redirect) {
	push(normalized, {
		type: 'redirect',
		tag: 'redirect-in',
		listen: '0.0.0.0',
		listen_port: redir_port
	});
}

if (!has_mixed) {
	push(normalized, {
		type: 'mixed',
		tag: 'mixed-in',
		listen: '0.0.0.0',
		listen_port: mixed_port
	});
}

if (wants_tun && !has_tun) {
	let tun_ib = {
		type: 'tun',
		tag: 'tun-in',
		address: [ '172.19.0.1/30', 'fdfe:dcba:9876::1/126' ],
		auto_route: true,
		auto_redirect: true,
		auto_redirect_input_mark: '0x2023',
		auto_redirect_output_mark: '0x2024',
		strict_route: true,
		stack: tun_stack
	};
	ensure_tun_dnsmasq_exclude(tun_ib);
	ensure_tun_cn_exclude(tun_ib);
	push(normalized, tun_ib);
}

if (!has_tproxy) {
	push(normalized, {
		type: 'tproxy',
		tag: 'tproxy-in',
		listen: '0.0.0.0',
		listen_port: tproxy_port,
		network: 'udp'
	});
}

if (!has_dns_in) {
	push(normalized, {
		type: 'direct',
		tag: 'dns-in',
		listen: '0.0.0.0',
		listen_port: dns_port
	});
}

cfg.inbounds = normalized;

for (let ob in (cfg.outbounds || [])) {
	if (!ob || type(ob) != 'object')
		continue;

	let t = ob.type || '';
	if (t == 'selector' || t == 'urltest' || t == 'fallback' || t == 'load_balance' || t == 'dns' || t == 'block')
		continue;

		/* Clash SS obfs is plugin=obfs + plugin-opts object; sing-box wants
		 * plugin=obfs-local + "obfs=http;obfs-host=..." string. */
		if (ob.plugin == 'obfs')
			ob.plugin = 'obfs-local';
		if (ob.plugin_opts != null && type(ob.plugin_opts) == 'object') {
			let _parts = [];
			let _map = { mode: 'obfs', host: 'obfs-host', uri: 'obfs-uri' };
			for (let _k in ob.plugin_opts) {
				let _v = ob.plugin_opts[_k];
				if (type(_v) == 'object' || type(_v) == 'array') continue;
				push(_parts, (_map[_k] || _k) + '=' + _v);
			}
			ob.plugin_opts = join(';', _parts);
		}
		if (ob.plugin != null && ob.plugin != 'obfs-local' && ob.plugin != 'v2ray-plugin' && ob.plugin != 'shadow-tls') {
			delete ob.plugin;
			delete ob.plugin_opts;
		}

		/* Force ipv4_only on DIRECT outbound: most devices are IPv4-only egress,
		 * a CN domain resolving AAAA stalls on "network is unreachable". */
		if (ob.type == 'direct' && ob.tag == 'DIRECT')
			ob.domain_resolver = { server: 'dns_resolver', strategy: 'ipv4_only' };

		if (wants_tun) {
			delete ob.routing_mark;
			if (ob.type == 'direct' && ob.tag == 'DIRECT' && default_interface)
				ob.bind_interface = ob.bind_interface || default_interface;
		} else if (ob.routing_mark == null)
			ob.routing_mark = routing_mark;
	}

/* Drop airline pseudo-nodes (Traffic:/Expire:/quota/官网/QQ/etc.) from selector/urltest lists.
 * They're real SS/Vmess (kept so the UI reads traffic/expiry) but don't forward; in a
 * selector/urltest they win and swallow foreign traffic ("CN ok, foreign out"). */
let _is_pseudo_tag = function(t) {
	if (!t) return false;
	return match(t, /^Traffic[：:]/) || match(t, /^Expire[：:]/) ||
	       match(t, /剩余流量|剩余[：:]/) || match(t, /距离下次重置/) ||
	       match(t, /到期(时间|日期)?[：:]/) ||
	       match(t, /官网[：:]|网站[：:]|套餐[：:]?|客服[：:]/) ||
	       match(t, /QQ[群]?[：:]/) || match(t, /Telegram|TG群|官方群/) ||
	       match(t, /续费|订阅地址|流量重置/);
};
for (let ob in (cfg.outbounds || [])) {
	if (!ob || type(ob) != 'object') continue;
	let t = ob.type || '';
	if (t != 'selector' && t != 'urltest' && t != 'fallback' && t != 'load_balance') continue;
	if (type(ob.outbounds) != 'array') continue;
	let cleaned = [];
	for (let tag in ob.outbounds) if (!_is_pseudo_tag(tag)) push(cleaned, tag);
	ob.outbounds = cleaned;
}

cfg.route = cfg.route || {};
cfg.route.rules = cfg.route.rules || [];
let has_dns_hijack = false;
for (let rule in cfg.route.rules) {
	if (!rule || type(rule) != 'object')
		continue;
	if (rule.inbound == 'dns-in' && rule.action == 'hijack-dns') {
		has_dns_hijack = true;
		break;
	}
}
if (!has_dns_hijack) {
	unshift(cfg.route.rules, {
		inbound: 'dns-in',
		action: 'hijack-dns'
	});
}
cfg.route.auto_detect_interface = true;
apply_dns_from_uci();

/* DNS leak protection: reject DoT/DoQ (853) to force DNS through the core; after hijack-dns so the dns inbound survives */
if (opt_bool(uci_opt('dns_leak_protect', '0'), false)) {
	let _has_853 = false;
	for (let _r in cfg.route.rules) {
		if (_r && type(_r) == 'object' && _r.action == 'reject' && _r.port) {
			if (type(_r.port) == 'array') {
				for (let _p in _r.port) if (_p == 853) { _has_853 = true; break; }
			} else if (_r.port == 853) {
				_has_853 = true;
			}
		}
		if (_has_853) break;
	}
	if (!_has_853) {
		let _new_rules = [];
		let _inserted = false;
		for (let _ri = 0; _ri < length(cfg.route.rules); _ri++) {
			push(_new_rules, cfg.route.rules[_ri]);
			if (!_inserted && cfg.route.rules[_ri] && cfg.route.rules[_ri].action == 'hijack-dns') {
				push(_new_rules, { port: [853], action: 'reject' });
				_inserted = true;
			}
		}
		if (!_inserted) unshift(_new_rules, { port: [853], action: 'reject' });
		cfg.route.rules = _new_rules;
	}
}

/* ===== Custom routing rules (UCI: config addtype) -> route.rules, mirrors mihomo iprules.sh =====
 * User "domain/IP -> direct/proxy" rules from LuCI, inserted after the DNS funnel
 * (hijack-dns / 853-reject) and before other rules, so overrides win without bypassing it. */
let _proxy_outbound_tag = function() {
	for (let ob in (cfg.outbounds || []))
		if (ob && ob.tag == '🚀 节点选择' && (ob.type == 'selector' || ob.type == 'urltest'))
			return ob.tag;
	for (let ob in (cfg.outbounds || []))
		if (ob && ob.type == 'selector' && s_len(ob.tag || '') && !_is_pseudo_tag(ob.tag))
			return ob.tag;
	return direct_outbound_tag();
};
let _load_addtype_rules = function() {
	let out = [];
	let dtag = direct_outbound_tag();
	let ptag = null;
	for (let s in uci_sections('addtype')) {
		let o = s.options || {};
		let addr = trim_s(o.ipaaddr || '');
		let rtype = trim_s(o.type || '');
		let pg = trim_s(o.pgroup || '');
		if (!s_len(addr) || !s_len(rtype) || !s_len(pg))
			continue;
		let r = {};
		if (rtype == 'DOMAIN')
			r.domain = addr;
		else if (rtype == 'DOMAIN-SUFFIX')
			r.domain_suffix = addr;
		else if (rtype == 'DOMAIN-KEYWORD')
			r.domain_keyword = addr;
		else if (rtype == 'IP-CIDR' || rtype == 'IP-CIDR6')
			r.ip_cidr = addr;
		else
			continue;
		if (pg == 'DIRECT')
			r.outbound = dtag;
		else {
			if (ptag == null)
				ptag = _proxy_outbound_tag();
			r.outbound = ptag;
		}
		push(out, r);
	}
	return out;
};
let _addtype_rules = _load_addtype_rules();
if (length(_addtype_rules)) {
	let _nr = [];
	let _ins = false;
	for (let _i = 0; _i < length(cfg.route.rules); _i++) {
		let _ru = cfg.route.rules[_i];
		let _dns_front = _ru && type(_ru) == 'object' &&
			(_ru.action == 'hijack-dns' || (_ru.action == 'reject' && _ru.port));
		if (!_ins && !_dns_front) {
			for (let _cr in _addtype_rules)
				push(_nr, _cr);
			_ins = true;
		}
		push(_nr, _ru);
	}
	if (!_ins)
		for (let _cr in _addtype_rules)
			push(_nr, _cr);
	cfg.route.rules = _nr;
}

if (uci_opt('enhanced_mode', 'fake-ip') == 'fake-ip') {
	add_remote_rule_set('geolocation-!cn',
		'https://github.com/MetaCubeX/meta-rules-dat/raw/refs/heads/sing/geo/geosite/geolocation-!cn.srs');
}

/* Local .srs -> local; remaining remote rule_sets must keep/get a download_detour.
 * CN first-start deadlock: no srs -> fetch rules -> via auto-select -> urltest dials
 *   the proxy -> resolves its domain -> pulled into an unloaded rule_set by DNS rules -> deadline.
 * The srs URLs use a CN-reachable mirror, so download_detour
 * must be DIRECT (real direct-outbound tag if any, else 'DIRECT'). */
let _pick_dl_detour = function() {
	if (cfg.outbounds) {
		for (let ob in cfg.outbounds) {
			if (ob && ob.type == 'direct' && ob.tag) return ob.tag;
		}
	}
	return 'DIRECT';
};
let _dl_detour = _pick_dl_detour();
for (let rs in (cfg.route || {}).rule_set || []) {
	if (!rs) continue;
	if (rs.type != 'remote') { delete rs.download_detour; continue; }
	let path = local_rule_set_path(rs.tag || '');
	if (rs.tag && access(path, 'r')) {
		delete rs.url; delete rs.download_detour; rs.type = 'local'; rs.path = path;
		continue;
	}
	if (keep_remote_rule_set(rs) && rs.url) {
		rs.url = normalize_rule_set_url(rs.url);
		rs.download_detour = _dl_detour;
		continue;
	}
	/* No local cache -> skip this remote rule_set so a failed download doesn't block start.
	 * Rule-sets are fetched to /usr/share/clashoo/ruleset/ once proxied. */
	continue;

}
/* filter out remote rule_sets with no local cache */
let _clean_rs = [];
for (let _rsi = 0; _rsi < length(cfg.route.rule_set); _rsi++) {
	let _rs = cfg.route.rule_set[_rsi];
	if (!_rs) continue;
	if (_rs.type == 'remote' && _rs.url != null) {
		let _local_path = local_rule_set_path(_rs.tag || '');
		if (!_rs.tag || !access(_local_path, 'r'))
			if (keep_remote_rule_set(_rs) && _rs.url) {
				_rs.url = normalize_rule_set_url(_rs.url);
				_rs.download_detour = _dl_detour;
				push(_clean_rs, _rs);
				continue;
			} else {
				continue; /* no local cache -> drop from final list */
			}
		/* has local cache -> convert to local */
		delete _rs.url; delete _rs.download_detour; _rs.type = 'local'; _rs.path = _local_path;
	}
	push(_clean_rs, _rs);
}
cfg.route.rule_set = _clean_rs;
prune_tun_cn_exclude_if_missing();

	/* drop DNS/route rules referencing a removed rule_set, else sing-box FATAL: rule-set not found */
	let _existing_tags = {};
	for (let _rs in cfg.route.rule_set || []) if (_rs && _rs.tag) _existing_tags[_rs.tag] = true;
	let _rule_has_ref = function(_r) {
		if (!_r || type(_r) != 'object') return false;
		if (_r.rule_set) {
			if (type(_r.rule_set) == 'array') { for (let _t in _r.rule_set) if (!_existing_tags[_t]) return false; }
			else if (!_existing_tags[_r.rule_set]) return false;
		}
		return true;
	};
	/* clean dns.rules */
	if (cfg.dns && type(cfg.dns.rules) == 'array') {
		let _clean_dns_rules = [];
		for (let _dr in cfg.dns.rules) if (_rule_has_ref(_dr)) push(_clean_dns_rules, _dr);
		cfg.dns.rules = _clean_dns_rules;
	}
	/* clean route.rules */
	if (cfg.route && type(cfg.route.rules) == 'array') {
		let _clean_rt_rules = [];
		for (let _rr in cfg.route.rules) if (_rule_has_ref(_rr)) push(_clean_rt_rules, _rr);
		cfg.route.rules = _clean_rt_rules;
	}
	cfg.experimental = cfg.experimental || {};
cfg.experimental.clash_api = cfg.experimental.clash_api || {};
cfg.experimental.clash_api.external_controller = '0.0.0.0:' + dash_port;
cfg.experimental.clash_api.external_ui = '/etc/clashoo/dashboard';
cfg.experimental.clash_api.secret = dash_secret;

cfg.experimental.cache_file = {
	enabled: true,
	store_fakeip: true
};

/* OpenWrt already owns system time sync. Keep sing-box NTP disabled by
 * default to avoid noisy IPv6 UDP/123 failures on IPv4-only routers. */
cfg.ntp = cfg.ntp || {};
cfg.ntp.enabled = false;

cfg.log = cfg.log || {};
cfg.log.output = '/var/log/clashoo/core.log';
if (!cfg.log.level)
	cfg.log.level = 'info';

if (writefile(path, sprintf('%J', cfg)) === null) {
	print("write failed\n");
	exit(1);
}

print("normalized\n");
