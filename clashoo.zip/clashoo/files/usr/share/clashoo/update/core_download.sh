#!/bin/sh

LOG_FILE="/tmp/clash_update.txt"
MODELTYPE=$(uci get clashoo.config.download_core 2>/dev/null)
# When invoked with a target dcore arg (the component "core update" button),
# download that core WITHOUT switching the active kernel — see finalize().
# No arg = legacy callers (manual download_core RPC / boot) use the active dcore.
TARGET_DCORE="$1"
CORETYPE=${TARGET_DCORE:-$(uci get clashoo.config.dcore 2>/dev/null)}
MIRROR_PREFIX=$(uci get clashoo.config.core_mirror_prefix 2>/dev/null)
CUSTOM_CORE_URL=$(uci get clashoo.config.core_download_url 2>/dev/null)
SINGBOX_STABLE_TARGET="${CLASHOO_SINGBOX_STABLE_TARGET:-/usr/share/clashoo/bin/sing-box-stable}"
SINGBOX_ALPHA_TARGET="${CLASHOO_SINGBOX_ALPHA_TARGET:-/usr/share/clashoo/bin/sing-box-alpha}"
SINGBOX_TMP_TEMPLATE="${CLASHOO_SINGBOX_TMP_TEMPLATE:-/tmp/clashoo-singbox.XXXXXX}"
CORE_DOWNLOAD_LOCK_DIR="${CLASHOO_CORE_DOWNLOAD_LOCK_DIR:-/var/lock/clashoo-core-download.lock}"
CORE_DOWNLOAD_LOCK_HELD=0
CORE_INSTALLED=0
CONNECT_TIMEOUT=15
REQUEST_TIMEOUT=30
DOWNLOAD_TIMEOUT=60
LOW_SPEED_TIME=15
LOW_SPEED_LIMIT=32768
ATTEMPTS_PER_MIRROR=1
MAX_TOTAL_SECONDS=200
TAG_FETCH_RETRIES=2
START_TS=$(date +%s)

write_log() {
	echo "  $(date "+%Y-%m-%d %H:%M:%S") - $1" >> "$LOG_FILE"
}

core_download_pid_alive() {
	local pid
	pid="$1"
	[ -d "/proc/$pid" ] && return 0
	kill -0 "$pid" >/dev/null 2>&1
}

acquire_core_download_lock() {
	local owner parent
	parent="$(dirname "$CORE_DOWNLOAD_LOCK_DIR")"
	mkdir -p "$parent" >/dev/null 2>&1 || return 1
	while :; do
	if mkdir "$CORE_DOWNLOAD_LOCK_DIR" 2>/dev/null; then
			printf '%s\n' "$$" > "$CORE_DOWNLOAD_LOCK_DIR/pid" || {
				rmdir "$CORE_DOWNLOAD_LOCK_DIR" >/dev/null 2>&1 || true
				return 1
			}
			CORE_DOWNLOAD_LOCK_HELD=1
			return 0
		fi

		if [ ! -e "$CORE_DOWNLOAD_LOCK_DIR/pid" ]; then
			# A fresh owner creates the directory before writing its PID.  Only
			# remove an actually empty directory; otherwise treat it as busy.
			if rmdir "$CORE_DOWNLOAD_LOCK_DIR" >/dev/null 2>&1; then
				continue
			fi
			return 1
		fi
		owner="$(sed -n '1p' "$CORE_DOWNLOAD_LOCK_DIR/pid" 2>/dev/null)"
		case "$owner" in
			'' ) return 1 ;;
			*[!0-9]*)
				rm -f "$CORE_DOWNLOAD_LOCK_DIR/pid" >/dev/null 2>&1 || return 1
				rmdir "$CORE_DOWNLOAD_LOCK_DIR" >/dev/null 2>&1 || return 1
				;;
			*)
				if core_download_pid_alive "$owner"; then
					return 1
				fi
				rm -f "$CORE_DOWNLOAD_LOCK_DIR/pid" >/dev/null 2>&1 || return 1
				rmdir "$CORE_DOWNLOAD_LOCK_DIR" >/dev/null 2>&1 || return 1
				;;
		esac
	done
}

release_core_download_lock() {
	local owner
	[ "$CORE_DOWNLOAD_LOCK_HELD" = "1" ] || return 0
	owner="$(sed -n '1p' "$CORE_DOWNLOAD_LOCK_DIR/pid" 2>/dev/null)"
	if [ "$owner" = "$$" ]; then
		rm -f "$CORE_DOWNLOAD_LOCK_DIR/pid" >/dev/null 2>&1
		rmdir "$CORE_DOWNLOAD_LOCK_DIR" >/dev/null 2>&1 || true
	fi
	CORE_DOWNLOAD_LOCK_HELD=0
}

finalize() {
	if [ "$CORE_INSTALLED" = "1" ]; then
		if [ -n "$TARGET_DCORE" ]; then
			# "core update" path: only refresh the binary. Apply (restart) only
			# when we updated the kernel that is actually running, so updating
			# smart / sing-box never hijacks the active kernel — and updating
			# several cores doesn't rotate through a restart for each. Switching
			# kernels stays a separate user action (set_core handles strategy).
			if [ "$TARGET_DCORE" = "$(uci get clashoo.config.dcore 2>/dev/null)" ]; then
				write_log "当前内核已更新，重启 Clashoo 生效"
				if [ "$(uci -q get clashoo.config.enable 2>/dev/null)" = "1" ]; then
					/etc/init.d/clashoo restart >/dev/null 2>&1 || write_log "重启 Clashoo 失败"
				fi
			else
				write_log "内核二进制已更新（非当前内核，不切换、不重启）"
			fi
		else
			# legacy callers (manual download_core RPC / boot): unchanged behavior
			if [ "$CORETYPE" = "1" ]; then
				uci set clashoo.config.core_type="mihomo" 2>/dev/null
				uci set clashoo.config.smart_auto_switch="1" 2>/dev/null
				uci commit clashoo 2>/dev/null
				write_log "Smart 内核已就绪，自动启用 Smart 策略"
			fi
			write_log "内核已替换，重启 Clashoo"
			if [ "$(uci -q get clashoo.config.enable 2>/dev/null)" = "1" ]; then
				/etc/init.d/clashoo restart >/dev/null 2>&1 || write_log "重启 Clashoo 失败"
			fi
		fi
	fi
	rm -f /var/run/core_update >/dev/null 2>&1
	release_core_download_lock
}

timed_out() {
	now_ts=$(date +%s)
	[ $((now_ts - START_TS)) -ge "$MAX_TOTAL_SECONDS" ]
}

ensure_not_timed_out() {
	if timed_out; then
		write_log "下载超时（超过 ${MAX_TOTAL_SECONDS} 秒）"
		return 1
	fi
	return 0
}

normalize_prefix() {
	p="$1"
	[ -z "$p" ] && return
	case "$p" in
		*/) printf '%s\n' "$p" ;;
		*) printf '%s/\n' "$p" ;;
	esac
}

mirror_prefixes() {
	# 默认源按 2026-04 实测排序：mirror.ghproxy.com 已挂、hub.gitmirror.com/git.886.be 全死、
	# gh.idayer.com/ghproxy.net 限速截断；只保留 gh-proxy.com + ghfast.top 两条快通道。
	# 末尾会自动追加裸 GitHub（download_with_mirrors 末尾会 push 一个空 prefix）。
	custom="$(normalize_prefix "$MIRROR_PREFIX")"
	prefixes=""
	for prefix in "$custom" "https://gh-proxy.com/" "https://ghfast.top/"; do
		[ -n "$prefix" ] || continue
		case " $prefixes " in
			*" $prefix "*) ;;
			*) prefixes="${prefixes}${prefixes:+ }${prefix}" ;;
		esac
	done
	printf '%s\n' "$prefixes"
}

prefixed_url() {
	prefix="$1"
	base_url="$2"
	if [ -z "$prefix" ]; then
		echo "$base_url"
	else
		echo "${prefix}${base_url}"
	fi
}

fetch_url_try() {
	url="$1"
	if command -v curl >/dev/null 2>&1; then
		curl -fsSL --connect-timeout "$CONNECT_TIMEOUT" --max-time "$REQUEST_TIMEOUT" -A "Clash/OpenWRT" "$url"
		return $?
	fi
	if command -v wget >/dev/null 2>&1; then
		wget -qO- --timeout="$CONNECT_TIMEOUT" --user-agent="Clash/OpenWRT" "$url"
		return $?
	fi
	return 127
}

# Route core downloads through the running core in kernel-only mode (shared
# logic in proxy_lib.sh: handles smart core + sing-box's own profile port).
if [ "${CLASHOO_CORE_DOWNLOAD_LIB_ONLY:-0}" = "1" ]; then
	detect_proxy() { :; }
else
	. /usr/share/clashoo/update/proxy_lib.sh
	detect_proxy() { clashoo_detect_proxy; }
fi

download_file_try() {
	url="$1"
	out="$2"
	proxy="$3"
	if command -v curl >/dev/null 2>&1; then
		if [ -n "$proxy" ]; then
			curl -fsSL --connect-timeout "$CONNECT_TIMEOUT" --max-time "$DOWNLOAD_TIMEOUT" --speed-time "$LOW_SPEED_TIME" --speed-limit "$LOW_SPEED_LIMIT" --retry 0 -A "Clash/OpenWRT" --proxy "$proxy" "$url" -o "$out"
		else
			curl -fsSL --connect-timeout "$CONNECT_TIMEOUT" --max-time "$DOWNLOAD_TIMEOUT" --speed-time "$LOW_SPEED_TIME" --speed-limit "$LOW_SPEED_LIMIT" --retry 0 -A "Clash/OpenWRT" "$url" -o "$out"
		fi
		return $?
	fi
	if command -v wget >/dev/null 2>&1; then
		wget -q --timeout="$REQUEST_TIMEOUT" --user-agent="Clash/OpenWRT" "$url" -O "$out"
		return $?
	fi
	return 127
}

head_url_try() {
	url="$1"
	if command -v curl >/dev/null 2>&1; then
		curl -fsSIL --connect-timeout "$CONNECT_TIMEOUT" --max-time "$REQUEST_TIMEOUT" -A "Clash/OpenWRT" "$url" >/dev/null 2>&1
		return $?
	fi
	wget -q --spider --timeout="$CONNECT_TIMEOUT" --user-agent="Clash/OpenWRT" "$url"
}

map_mihomo_arch() {
	# 上游 amd64 默认 v3 微架构（要 AVX2）跑不起来；default 给 compatible 兜底
	case "$1" in
		amd64-compatible) echo "linux-amd64-compatible" ;;
		amd64-v1)         echo "linux-amd64-v1" ;;
		amd64-v2)         echo "linux-amd64-v2" ;;
		amd64-v3)         echo "linux-amd64-v3" ;;
		amd64|x86_64)     echo "linux-amd64-compatible" ;;
		arm64|aarch64*) echo "linux-arm64" ;;
		armv7|arm_cortex-a[7-9]*|arm_cortex-a1[0-9]*) echo "linux-armv7" ;;
		armv6|arm_cortex-a[56]*|arm_arm1176*) echo "linux-armv6" ;;
		armv5|arm_cortex-a5*|arm_arm926*) echo "linux-armv5" ;;
		386|i[3-6]86|i386*) echo "linux-386" ;;
		mipsle|mipsel_24kc) echo "linux-mipsle-softfloat" ;;
		mips|mips_24kc) echo "linux-mips-softfloat" ;;
		mips64le|mips64el_mips64r2) echo "linux-mips64le" ;;
		mips64|mips64_mips64r2) echo "linux-mips64" ;;
		riscv64) echo "linux-riscv64" ;;
		*) echo "linux-amd64-compatible" ;;
	esac
}

map_singbox_arch() {
	case "$1" in
		amd64|amd64-compatible|amd64-v1|amd64-v2|amd64-v3) echo "amd64" ;;
		arm64|aarch64*)             echo "arm64" ;;
		armv7|arm_cortex-a[7-9]*|arm_cortex-a1[0-9]*) echo "armv7" ;;
		armv6|arm_cortex-a[56]*|arm_arm1176*)         echo "armv6" ;;
		armv5|arm_cortex-a5*|arm_arm926*)             echo "armv5" ;;
		386|i[3-6]86|i386*)         echo "386" ;;
		mips|mips_24kc)             echo "mips" ;;
		mipsle|mipsel_24kc)         echo "mipsle" ;;
		mips64|mips64_mips64r2)     echo "mips64" ;;
		mips64le|mips64el_mips64r2) echo "mips64le" ;;
		riscv64)                    echo "riscv64" ;;
		*)                          echo "amd64" ;;
	esac
}

map_openwrt_arch() {
	case "$1" in
		amd64|amd64-compatible|amd64-v1|amd64-v2|amd64-v3|x86_64) echo "x86_64" ;;
		arm64)        echo "aarch64_generic" ;;
		armv7)        echo "arm_cortex-a7_neon-vfpv4" ;;
		armv6)        echo "arm_arm1176jzf-s_vfp" ;;
		armv5)        echo "arm_arm926ej-s" ;;
		386)          echo "i386_pentium4" ;;
		mipsle)       echo "mipsel_24kc" ;;
		mips)         echo "mips_24kc" ;;
		mips64le)     echo "mips64el_mips64r2" ;;
		mips64)       echo "mips64_mips64r2" ;;
		*)            echo "" ;;
	esac
}

# Auto-detect normalized arch (MODELTYPE format) from the running device.
# Tries opkg → DISTRIB_ARCH → apk --print-arch → uname -m.
# Normalizes to MODELTYPE format (same vocabulary as luci.clashoo and system.js).
_auto_detect_modeltype() {
	local raw norm
	if command -v opkg >/dev/null 2>&1; then
		raw="$(opkg print-architecture 2>/dev/null | awk '$1=="arch" && $2!="all" && $2!="noarch" {a=$2} END{print a}')"
	fi
	if [ -z "$raw" ] && [ -r /etc/openwrt_release ]; then
		raw="$(sed -n "s/^DISTRIB_ARCH=['\"]\\([^'\"]*\\)['\"]$/\\1/p" /etc/openwrt_release | head -n 1)"
	fi
	if [ -z "$raw" ] && command -v apk >/dev/null 2>&1; then
		raw="$(apk --print-arch 2>/dev/null)"
	fi
	[ -z "$raw" ] && raw="$(uname -m 2>/dev/null)"
	[ -z "$raw" ] && return 1
	case "$raw" in
		x86_64|amd64)         norm="amd64-compatible" ;;
		aarch64*|arm64)       norm="arm64" ;;
		armv7*|arm_cortex-a[7-9]*|arm_cortex-a1[0-9]*) norm="armv7" ;;
		armv6*|arm_cortex-a[56]*|arm_arm1176*)         norm="armv6" ;;
		armv5*|arm_cortex-a5*|arm_arm926*)             norm="armv5" ;;
		arm*)                                         norm="armv5" ;;
		i[3-6]86|i386*)       norm="386" ;;
		mips64el*)            norm="mips64le" ;;
		mips64*)              norm="mips64" ;;
		mipsel*)              norm="mipsle" ;;
		mips*)                norm="mips" ;;
		riscv64*)             norm="riscv64" ;;
	esac
	[ -z "$norm" ] && return 1
	echo "$norm"
	return 0
}

_is_amd64_arch() {
	case "$1" in
		amd64-compatible|amd64-v1|amd64-v2|amd64-v3) return 0 ;;
		*) return 1 ;;
	esac
}

append_unique_line() {
	list="$1"
	line="$2"
	[ -z "$line" ] && {
		printf '%s' "$list"
		return
	}
	case "
$list
" in
	*"
$line
"*)
		printf '%s' "$list"
		;;
	*)
		if [ -n "$list" ]; then
			printf '%s\n%s' "$list" "$line"
		else
			printf '%s' "$line"
		fi
		;;
	esac
}

pick_highest_stable_tag() {
	printf '%s\n' "$1" | sed '/^$/d;s/\r$//' | grep -E '^v[0-9]+([.][0-9]+){1,3}$' | sort -V | tail -n 1
}

pick_highest_prerelease_tag() {
	printf '%s\n' "$1" | sed '/^$/d;s/\r$//' | grep -E '^v[0-9]+([.][0-9]+){1,3}-[0-9A-Za-z.-]+$' | sort -V | tail -n 1
}

extract_release_tags_by_prerelease() {
	payload="$1"
	is_prerelease="$2"

	if command -v jsonfilter >/dev/null 2>&1; then
		printf '%s' "$payload" | jsonfilter -e "@[@.prerelease=${is_prerelease}].tag_name" 2>/dev/null
		return
	fi

	tags="$(printf '%s' "$payload" | grep -o '"tag_name"[[:space:]]*:[[:space:]]*"[^"]*"' | sed 's/.*"tag_name"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/')"
	flags="$(printf '%s' "$payload" | grep -o '"prerelease"[[:space:]]*:[[:space:]]*[a-z]*' | sed 's/.*:[[:space:]]*//')"
	[ -z "$tags" ] && return
	[ -z "$flags" ] && return

	tags_file="/tmp/clashoo-tags-$$"
	flags_file="/tmp/clashoo-pre-$$"
	printf '%s\n' "$tags" > "$tags_file"
	printf '%s\n' "$flags" > "$flags_file"
	awk -v want="$is_prerelease" 'NR==FNR { t[FNR]=$0; next } $0==want { print t[FNR] }' "$tags_file" "$flags_file"
	rm -f "$tags_file" "$flags_file" >/dev/null 2>&1
}

detect_openwrt_arch() {
	local arch
	if command -v opkg >/dev/null 2>&1; then
		arch="$(opkg print-architecture 2>/dev/null | awk '$1=="arch" && $2!="all" && $2!="noarch" {a=$2} END{print a}')"
		[ -n "$arch" ] && { echo "$arch"; return 0; }
	fi
	# DISTRIB_ARCH is authoritative for OpenWrt package arch naming.
	# apk --print-arch may return "aarch64" while sing-box release assets
	# use the full sub-arch (e.g. aarch64_generic / aarch64_cortex-a53).
	if [ -r /etc/openwrt_release ]; then
		arch="$(sed -n "s/^DISTRIB_ARCH=['\"]\\([^'\"]*\\)['\"]$/\\1/p" /etc/openwrt_release | head -n 1)"
		[ -n "$arch" ] && { echo "$arch"; return 0; }
	fi
	if command -v apk >/dev/null 2>&1; then
		arch="$(apk --print-arch 2>/dev/null)"
		[ -n "$arch" ] && { echo "$arch"; return 0; }
	fi
	map_openwrt_arch "$MODELTYPE"
}

singbox_target_path() {
	case "$CORETYPE" in
		5) printf '%s\n' "$SINGBOX_ALPHA_TARGET" ;;
		*) printf '%s\n' "$SINGBOX_STABLE_TARGET" ;;
	esac
}

extract_tar_file() {
	local archive dest
	archive="$1"
	dest="$2"
	case "$archive" in
		*.gz) tar -xzf "$archive" -C "$dest" >/dev/null 2>&1 ;;
		*.xz) tar -xJf "$archive" -C "$dest" >/dev/null 2>&1 || tar -xf "$archive" -C "$dest" >/dev/null 2>&1 ;;
		*.zst)
			if command -v unzstd >/dev/null 2>&1; then
				unzstd -c "$archive" 2>/dev/null | tar -xf - -C "$dest" >/dev/null 2>&1
			elif command -v zstd >/dev/null 2>&1; then
				zstd -dc "$archive" 2>/dev/null | tar -xf - -C "$dest" >/dev/null 2>&1
			else
				return 1
			fi
			;;
		*) tar -xf "$archive" -C "$dest" >/dev/null 2>&1 || tar -xzf "$archive" -C "$dest" >/dev/null 2>&1 ;;
	esac
}

extract_ar_data_tar() {
	local archive dest offset name size member
	archive="$1"
	dest="$2"
	offset=8
	[ "$(dd if="$archive" bs=8 count=1 2>/dev/null)" = '!<arch>' ] || return 1
	while :; do
		# Read fixed-width ar fields directly.  Do not put the full 60-byte
		# header in command substitution: shell command substitution strips
		# trailing newlines/spaces and makes length checks unreliable in ash.
		name="$(dd if="$archive" bs=1 skip="$offset" count=16 2>/dev/null | sed 's/[[:space:]].*$//')"
		name="${name%/}"
		size="$(dd if="$archive" bs=1 skip=$((offset + 48)) count=10 2>/dev/null | tr -d '[:space:]')"
		case "$size" in
			''|*[!0-9]*) return 1 ;;
		esac
		member="$dest/$name"
		case "$name" in
			data.tar.*)
				dd if="$archive" of="$member" bs=1 skip=$((offset + 60)) count="$size" 2>/dev/null || return 1
				printf '%s\n' "$member"
				return 0
				;;
		esac
		offset=$((offset + 60 + size))
		[ $((offset % 2)) -eq 0 ] || offset=$((offset + 1))
	done
}

extract_singbox_payload() {
	local pkg rootdir outer workdir payload data_tar candidate
	pkg="$1"
	rootdir="$2"
	outer="${rootdir}.outer"
	workdir="$(dirname "$rootdir")"
	payload="$workdir/sing-box.payload"
	data_tar=""
	rm -f "$payload" 2>/dev/null
	rm -rf "$rootdir" "$outer" 2>/dev/null
	if ! mkdir -p "$rootdir" "$outer"; then
		rm -rf "$rootdir" "$outer" 2>/dev/null
		return 1
	fi

	# IPK assets are ar/tar containers with a compressed data.tar.* member;
	# official fallback archives contain sing-box directly below a version dir.
	if tar -tf "$pkg" 2>/dev/null | grep -Eq '(^|/)data\.tar\.(gz|xz|zst)$'; then
		extract_tar_file "$pkg" "$outer" || {
			rm -rf "$rootdir" "$outer" 2>/dev/null
			return 1
		}
		for candidate in "$outer"/data.tar.*; do
			[ -f "$candidate" ] || continue
			data_tar="$candidate"
			break
		done
		if [ -z "$data_tar" ] || ! extract_tar_file "$data_tar" "$rootdir"; then
			rm -rf "$rootdir" "$outer" 2>/dev/null
			return 1
		fi
	else
		data_tar="$(extract_ar_data_tar "$pkg" "$outer" 2>/dev/null || true)"
		if [ -n "$data_tar" ]; then
			if ! extract_tar_file "$data_tar" "$rootdir"; then
				rm -rf "$rootdir" "$outer" 2>/dev/null
				return 1
			fi
		else
			if ! extract_tar_file "$pkg" "$rootdir"; then
				rm -rf "$rootdir" "$outer" 2>/dev/null
				return 1
			fi
		fi
	fi

	candidate="$(find "$rootdir" -type f -name sing-box 2>/dev/null | head -n 1)"
	if [ -n "$candidate" ] && [ -f "$candidate" ]; then
		if ! cp -f "$candidate" "$payload"; then
			rm -rf "$rootdir" "$outer" 2>/dev/null
			return 1
		fi
		rm -rf "$rootdir" "$outer" 2>/dev/null
		printf '%s\n' "$payload"
		return 0
	fi
	rm -rf "$rootdir" "$outer" 2>/dev/null
	return 1
}

cleanup_singbox_extract_workdir() {
	local workdir rootdir
	workdir="$1"
	rootdir="$workdir/root"
	rm -rf "$rootdir" "${rootdir}.outer" "$workdir" 2>/dev/null
}

install_singbox_openwrt_asset() {
	local pkg target workdir rootdir bin extract_rc rc
	pkg="$1"
	target="${2:-$(singbox_target_path)}"
	workdir="$(mktemp -d "$SINGBOX_TMP_TEMPLATE" 2>/dev/null)" || return 1
	rootdir="$workdir/root"
	bin="$(extract_singbox_payload "$pkg" "$rootdir")"
	extract_rc=$?
	if [ "$extract_rc" -eq 0 ]; then
		install_with_rollback "$bin" "$target" "${VER:-}"
		rc=$?
	else
		rc=1
	fi
	cleanup_singbox_extract_workdir "$workdir"
	return "$rc"
}

install_singbox_tar_asset() {
	local archive target workdir rootdir bin extract_rc rc
	archive="$1"
	target="${2:-$(singbox_target_path)}"
	workdir="$(mktemp -d "$SINGBOX_TMP_TEMPLATE" 2>/dev/null)" || return 1
	rootdir="$workdir/root"
	bin="$(extract_singbox_payload "$archive" "$rootdir")"
	extract_rc=$?
	if [ "$extract_rc" -eq 0 ]; then
		install_with_rollback "$bin" "$target" "${VER:-}"
		rc=$?
	else
		rc=1
	fi
	cleanup_singbox_extract_workdir "$workdir"
	return "$rc"
}

fetch_latest_tag() {
	repo="$1"
	api_url="https://api.github.com/repos/${repo}/releases/latest"
	list_api="https://api.github.com/repos/${repo}/releases?per_page=100"
	web_url="https://github.com/${repo}/releases/latest"
	candidates=""

	# Fast path: prefer official GitHub API first to avoid stale mirror cache.
	p=""
	ensure_not_timed_out || return 1
	u="$(prefixed_url "$p" "$api_url")"
	i=1
	while [ "$i" -le "$TAG_FETCH_RETRIES" ]; do
		ensure_not_timed_out || return 1
		tag="$(fetch_url_try "$u" | sed -n 's/.*"tag_name"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n 1)"
		case "$tag" in
			v*[-]*)
				:
				;;
			*)
				[ -n "$tag" ] && echo "$tag" && return 0
				;;
		esac
		sleep 1
		i=$((i + 1))
	done

	for p in $(mirror_prefixes); do
		ensure_not_timed_out || return 1
		u="$(prefixed_url "$p" "$api_url")"
		i=1
		while [ "$i" -le "$TAG_FETCH_RETRIES" ]; do
			ensure_not_timed_out || return 1
			tag="$(fetch_url_try "$u" | sed -n 's/.*"tag_name"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n 1)"
			case "$tag" in
				v*[-]*)
					# stable channel should ignore prerelease-like tags from stale mirrors
					:
					;;
				*)
					candidates="$(append_unique_line "$candidates" "$tag")"
					;;
			esac
			sleep 1
			i=$((i + 1))
		done
	done

	p=""
	ensure_not_timed_out || return 1
	u="$(prefixed_url "$p" "$list_api")"
	i=1
	while [ "$i" -le "$TAG_FETCH_RETRIES" ]; do
		ensure_not_timed_out || return 1
		payload="$({ fetch_url_try "$u" || true; })"
		tags="$(extract_release_tags_by_prerelease "$payload" false)"
		best="$(pick_highest_stable_tag "$tags")"
		[ -n "$best" ] && echo "$best" && return 0
		sleep 1
		i=$((i + 1))
	done

	for p in $(mirror_prefixes); do
		ensure_not_timed_out || return 1
		u="$(prefixed_url "$p" "$list_api")"
		i=1
		while [ "$i" -le "$TAG_FETCH_RETRIES" ]; do
			ensure_not_timed_out || return 1
			payload="$({ fetch_url_try "$u" || true; })"
			tags="$(extract_release_tags_by_prerelease "$payload" false)"
			for tag in $tags; do
				candidates="$(append_unique_line "$candidates" "$tag")"
			done
			sleep 1
			i=$((i + 1))
		done
	done

	for p in $(mirror_prefixes); do
		ensure_not_timed_out || return 1
		u="$(prefixed_url "$p" "$web_url")"
		i=1
		while [ "$i" -le "$TAG_FETCH_RETRIES" ]; do
			ensure_not_timed_out || return 1
			if command -v curl >/dev/null 2>&1; then
				tag="$(curl -fsSIL --connect-timeout "$CONNECT_TIMEOUT" --max-time "$REQUEST_TIMEOUT" -A "Clash/OpenWRT" "$u" 2>/dev/null | sed -n 's#^[Ll]ocation: .*/releases/tag/\([^[:space:]\r]*\).*#\1#p' | head -n 1)"
			else
				tag="$(wget -S --spider --timeout="$CONNECT_TIMEOUT" --user-agent="Clash/OpenWRT" "$u" 2>&1 | sed -n 's#^  Location: .*/releases/tag/\([^[:space:]]*\).*#\1#p' | head -n 1)"
			fi
			case "$tag" in
				v*[-]*)
					:
					;;
				*)
					candidates="$(append_unique_line "$candidates" "$tag")"
					;;
			esac
			sleep 1
			i=$((i + 1))
		done
	done

	releases_url="https://github.com/${repo}/releases"
	for p in $(mirror_prefixes); do
		ensure_not_timed_out || return 1
		u="$(prefixed_url "$p" "$releases_url")"
		tag="$(fetch_url_try "$u" | sed -n 's#.*releases/tag/\(v[0-9][^\"/?]*\).*#\1#p' | head -n 1)"
		case "$tag" in
			v*[-]*)
				:
				;;
			*)
				candidates="$(append_unique_line "$candidates" "$tag")"
				;;
		esac
	done

		# 终极兜底：直连 GitHub 爬取 releases 页面（镜像都失效时备用）
	ensure_not_timed_out || return 1
	p=""
	u="$(prefixed_url "$p" "$releases_url")"
	tag="$(fetch_url_try "$u" 2>/dev/null | sed -n 's#.*releases/tag/\(v[0-9][^"/?]*\).*#\1#p' | head -n 1)"
	case "$tag" in
		v*[-]*)
			;;
		*)
			[ -n "$tag" ] && { echo "$tag"; return 0; }
			;;
	esac
	# 再试一次 releases/latest 的 302 跳转
	u="$(prefixed_url "$p" "$web_url")"
	if command -v curl >/dev/null 2>&1; then
		tag="$(curl -fsSIL --connect-timeout "$CONNECT_TIMEOUT" --max-time "$REQUEST_TIMEOUT" -A "Clash/OpenWRT" "$u" 2>/dev/null | sed -n 's#^[Ll]ocation: .*/releases/tag/\([^[:space:][:cntrl:]]*\).*#\1#p' | head -n 1)"
	else
		tag="$(wget -S --spider --timeout="$CONNECT_TIMEOUT" --user-agent="Clash/OpenWRT" "$u" 2>&1 | sed -n 's#^  Location: .*/releases/tag/\([^[:space:]]*\).*#\1#p' | head -n 1)"
	fi
	[ -n "$tag" ] && { echo "$tag"; return 0; }

best="$(pick_highest_stable_tag "$candidates")"
	[ -n "$best" ] && {
		echo "$best"
		return 0
	}
	fallback="$(printf '%s\n' "$candidates" | sed '/^$/d' | head -n 1)"
	[ -n "$fallback" ] && {
		echo "$fallback"
		return 0
	}

	return 1
}

fetch_prerelease_tag() {
	repo="$1"
	api_url="https://api.github.com/repos/${repo}/releases?per_page=100"
	candidates=""

	# Fast path: official GitHub API first.
	p=""
	ensure_not_timed_out || return 1
	u="$(prefixed_url "$p" "$api_url")"
	i=1
	while [ "$i" -le "$TAG_FETCH_RETRIES" ]; do
		ensure_not_timed_out || return 1
		payload="$({ fetch_url_try "$u" || true; })"
		tags="$(extract_release_tags_by_prerelease "$payload" true)"
		best="$(pick_highest_prerelease_tag "$tags")"
		[ -n "$best" ] && echo "$best" && return 0
		sleep 1
		i=$((i + 1))
	done

	for p in $(mirror_prefixes); do
		ensure_not_timed_out || return 1
		u="$(prefixed_url "$p" "$api_url")"
		i=1
		while [ "$i" -le "$TAG_FETCH_RETRIES" ]; do
			ensure_not_timed_out || return 1
			payload="$({ fetch_url_try "$u" || true; })"
			tags="$(extract_release_tags_by_prerelease "$payload" true)"
			for tag in $tags; do
				candidates="$(append_unique_line "$candidates" "$tag")"
			done
			sleep 1
			i=$((i + 1))
		done
	done

	best="$(pick_highest_prerelease_tag "$candidates")"
	[ -n "$best" ] && {
		echo "$best"
		return 0
	}
	fallback="$(printf '%s\n' "$candidates" | sed '/^$/d' | head -n 1)"
	[ -n "$fallback" ] && {
		echo "$fallback"
		return 0
	}

	return 1
}

fetch_expanded_asset_names() {
	repo="$1"
	tag="$2"
	url="https://github.com/${repo}/releases/expanded_assets/${tag}"

	for p in $(mirror_prefixes) ""; do
		ensure_not_timed_out || return 1
		u="$(prefixed_url "$p" "$url")"
		assets="$(fetch_url_try "$u" | sed -n "s#.*releases/download/${tag}/\\([^\\\"?]*\\)\\\".*#\\1#p")"
		[ -n "$assets" ] && printf '%s\n' "$assets" && return 0
	done

	return 1
}

pick_reachable_release_url() {
	base_url="$1"
	for p in $(mirror_prefixes) ""; do
		ensure_not_timed_out || return 1
		u="$(prefixed_url "$p" "$base_url")"
		if head_url_try "$u"; then
			echo "$u"
			return 0
		fi
	done
	return 1
}

pick_mihomo_asset_by_url() {
	repo="$1"
	tag="$2"
	arch="$3"
	channel="$4"
	ver="${tag#v}"
	candidates=""

	if [ "$channel" = "alpha" ] || [ "$channel" = "smart" ]; then
		if [ "$arch" = "linux-amd64" ]; then
			if [ "$channel" = "smart" ]; then
				candidates="mihomo-linux-amd64-alpha-smart-*.gz mihomo-linux-amd64-compatible-alpha-smart-*.gz"
			else
				candidates="mihomo-linux-amd64-alpha-*.gz mihomo-linux-amd64-compatible-alpha-*.gz"
			fi
		else
			[ "$channel" = "smart" ] && candidates="mihomo-${arch}-alpha-smart-*.gz" || candidates="mihomo-${arch}-alpha-*.gz"
		fi
		assets_html="$(fetch_expanded_asset_names "$repo" "$tag")"
		if [ -n "$assets_html" ]; then
			for a in $(printf '%s\n' "$assets_html"); do
				for pat in $candidates; do
					case "$a" in
					$pat)
						u="https://github.com/${repo}/releases/download/${tag}/${a}"
						if pick_reachable_release_url "$u" >/dev/null 2>&1; then
							echo "$a"
							return 0
						fi
						;;
					esac
				done
			done
		fi
		return 1
	fi

	if [ "$arch" = "linux-amd64" ]; then
		candidates="mihomo-linux-amd64-v${ver}.gz mihomo-linux-amd64-compatible-v${ver}.gz"
	else
		candidates="mihomo-${arch}-v${ver}.gz"
	fi

	for a in $candidates; do
		u="https://github.com/${repo}/releases/download/${tag}/${a}"
		if pick_reachable_release_url "$u" >/dev/null 2>&1; then
			echo "$a"
			return 0
		fi
	done

	return 1
}

download_with_mirrors() {
	base_url="$1"
	outfile="$2"
	verify_mode="${3:-gzip}"
	proxy="$(detect_proxy)"
	if [ -n "$proxy" ]; then
		download_prefixes="__direct__ $(mirror_prefixes)"
	else
		download_prefixes="$(mirror_prefixes) __direct__"
	fi
	for p in $download_prefixes; do
		[ "$p" = "__direct__" ] && p=""
		ensure_not_timed_out || return 1
		u="$(prefixed_url "$p" "$base_url")"
		i=1
		while [ "$i" -le "$ATTEMPTS_PER_MIRROR" ]; do
			ensure_not_timed_out || return 1
			write_log "Downloading from ${u}"
			rm -f "$outfile" 2>/dev/null
			if download_file_try "$u" "$outfile" "$proxy"; then
				case "$verify_mode" in
					raw)
						if [ -s "$outfile" ]; then
							return 0
						fi
						write_log "Downloaded file is empty from ${u}"
						;;
					*)
						if gzip -t "$outfile" >/dev/null 2>&1; then
							return 0
						fi
						write_log "Downloaded file is invalid gzip from ${u}"
						;;
				esac
			fi
			sleep 1
			i=$((i + 1))
		done
	done
	return 1
}

pick_mihomo_asset() {
	repo="$1"
	tag="$2"
	arch="$3"
	channel="$4"
	ver="${tag#v}"
	candidates=""
	release_assets="$(fetch_expanded_asset_names "$repo" "$tag")"
	[ -z "$release_assets" ] && pick_mihomo_asset_by_url "$repo" "$tag" "$arch" "$channel" && return 0
	[ -z "$release_assets" ] && return 1

	if [ "$channel" = "alpha" ] || [ "$channel" = "smart" ]; then
		if [ "$arch" = "linux-amd64" ]; then
			if [ "$channel" = "smart" ]; then
				asset="$(printf '%s\n' "$release_assets" | sed -n 's#^\(mihomo-linux-amd64-alpha-smart-[0-9a-fA-F]\{7,\}\.gz\)$#\1#p' | head -n 1)"
				[ -z "$asset" ] && asset="$(printf '%s\n' "$release_assets" | sed -n 's#^\(mihomo-linux-amd64-compatible-alpha-smart-[0-9a-fA-F]\{7,\}\.gz\)$#\1#p' | head -n 1)"
			else
				asset="$(printf '%s\n' "$release_assets" | sed -n 's#^\(mihomo-linux-amd64-alpha-[0-9a-fA-F]\{7,\}\.gz\)$#\1#p' | head -n 1)"
				[ -z "$asset" ] && asset="$(printf '%s\n' "$release_assets" | sed -n 's#^\(mihomo-linux-amd64-compatible-alpha-[0-9a-fA-F]\{7,\}\.gz\)$#\1#p' | head -n 1)"
			fi
		else
			if [ "$channel" = "smart" ]; then
				asset="$(printf '%s\n' "$release_assets" | sed -n "s#^\\(mihomo-${arch}-alpha-smart-[0-9a-fA-F]\\{7,\\}\\.gz\\)$#\\1#p" | head -n 1)"
			else
				asset="$(printf '%s\n' "$release_assets" | sed -n "s#^\\(mihomo-${arch}-alpha-[0-9a-fA-F]\\{7,\\}\\.gz\\)$#\\1#p" | head -n 1)"
			fi
		fi
		[ -n "$asset" ] && echo "$asset" && return 0
		pick_mihomo_asset_by_url "$repo" "$tag" "$arch" "$channel"
		return $?
	fi

	if [ "$arch" = "linux-amd64" ]; then
		candidates="mihomo-linux-amd64-v${ver}.gz mihomo-linux-amd64-compatible-v${ver}.gz"
	else
		candidates="mihomo-${arch}-v${ver}.gz"
	fi

	for a in $candidates; do
		if printf '%s\n' "$release_assets" | grep -qx "$a"; then
			echo "$a"
			return 0
		fi
	done

	pick_mihomo_asset_by_url "$repo" "$tag" "$arch" "$channel"
	return $?

}

install_binary() {
	local src dst dir staged
	src="$1"
	dst="$2"
	dir="$(dirname "$dst")"
	staged="$dir/.$(basename "$dst").tmp.$$"
	mkdir -p "$dir" || return 1
	rm -f "$staged"
	cp -f "$src" "$staged" || {
		rm -f "$staged"
		return 1
	}
	chmod 755 "$staged" || {
		rm -f "$staged"
		return 1
	}
	mv -f "$staged" "$dst" || {
		rm -f "$staged"
		return 1
	}
}

backup_binary() {
	dst="$1"
	bak="${dst}.bak"
	if [ -x "$dst" ]; then
		cp -f "$dst" "$bak" 2>/dev/null || true
		[ -f "$bak" ] || { write_log "备份旧内核失败（磁盘满？），跳过备份"; }
	fi
}

restore_binary() {
	dst="$1"
	bak="${dst}.bak"
	if [ -f "$bak" ]; then
		cp -f "$bak" "$dst" 2>/dev/null || return 1
		chmod 755 "$dst" 2>/dev/null || true
		return 0
	fi
	return 1
}

verify_binary() {
	local bin
	bin="$1"
	[ -x "$bin" ] || return 1
	"$bin" -v >/dev/null 2>&1 && return 0
	"$bin" version >/dev/null 2>&1 && return 0
	return 1
}

verify_binary_version() {
	local bin expected output actual
	bin="$1"
	expected="$2"
	[ -n "$expected" ] || return 0
	output="$({ "$bin" version 2>/dev/null || "$bin" -v 2>/dev/null; } || true)"
	[ -n "$output" ] || return 1
	actual="$(printf '%s\n' "$output" | sed -n 's/^[[:space:]]*sing-box[[:space:]][[:space:]]*version[[:space:]][[:space:]]*\([^[:space:]][^[:space:]]*\).*/\1/p' | head -n 1)"
	[ -n "$actual" ] || return 1
	[ "$actual" = "$expected" ]
}

installed_version_matches() {
	version_file="$1"
	expected_version="$2"
	[ -r "$version_file" ] || return 1
	[ -n "$expected_version" ] || return 1
	[ "$(sed -n '1p' "$version_file" 2>/dev/null)" = "$expected_version" ]
}

install_with_rollback() {
	local tmpfile target expected_version
	tmpfile="$1"
	target="$2"
	expected_version="${3:-}"

	chmod 755 "$tmpfile" 2>/dev/null
	if ! verify_binary "$tmpfile" || ! verify_binary_version "$tmpfile" "$expected_version"; then
		write_log "新内核预热校验失败，保留当前内核"
		rm -f "$tmpfile" 2>/dev/null
		return 1
	fi

	backup_binary "$target"
	if ! install_binary "$tmpfile" "$target"; then
		write_log "内核替换失败，回滚旧版本"
		restore_binary "$target" >/dev/null 2>&1 || true
		return 1
	fi

	rm -f "${target}.bak" 2>/dev/null
	return 0
}

# Unit tests source the extraction helpers without entering the normal UCI and
# network download path.  This hook has no effect in production execution.
if [ "${CLASHOO_CORE_DOWNLOAD_LIB_ONLY:-0}" = "1" ]; then
	return 0 2>/dev/null || exit 0
fi

if ! acquire_core_download_lock; then
	write_log "已有内核下载任务运行，拒绝并发执行"
	exit 1
fi
trap finalize EXIT

# UCI template defaults to amd64-compatible. Auto-detect when MODELTYPE
# is missing, or when MODELTYPE is an amd64 variant but the device is not.
if [ -z "$MODELTYPE" ]; then
	DETECTED="$(_auto_detect_modeltype)"
	if [ -n "$DETECTED" ] && [ "$DETECTED" != "$MODELTYPE" ]; then
		write_log "自动识别处理器架构：${DETECTED}"
		MODELTYPE="$DETECTED"
		uci set clashoo.config.download_core="$DETECTED" 2>/dev/null
		uci commit clashoo 2>/dev/null
	fi
elif _is_amd64_arch "$MODELTYPE"; then
	DETECTED="$(_auto_detect_modeltype)"
	if [ -n "$DETECTED" ] && [ "$DETECTED" != "$MODELTYPE" ] && ! _is_amd64_arch "$DETECTED"; then
		write_log "UCI 架构为 ${MODELTYPE}，但设备检测为 ${DETECTED}，自动修正"
		MODELTYPE="$DETECTED"
		uci set clashoo.config.download_core="$DETECTED" 2>/dev/null
		uci commit clashoo 2>/dev/null
	fi
fi

rm -f /tmp/clash.gz /tmp/clash /usr/share/clashoo/core_down_complete 2>/dev/null
touch /var/run/core_update 2>/dev/null
write_log "内核下载任务启动"
write_log "下载架构：${MODELTYPE:-未设置}"

if [ -n "$CUSTOM_CORE_URL" ]; then
	write_log "使用自定义内核下载链接"
	URL="$CUSTOM_CORE_URL"
	if [ "$CORETYPE" = "3" ]; then
		TARGET="/usr/bin/mihomo"
		VERSION_FILE="/usr/share/clashoo/mihomo_version"
	else
		TARGET="/usr/bin/mihomo-stable"
		VERSION_FILE="/usr/share/clashoo/clash_meta_version"
	fi
	TAG="custom"
	ASSET="custom"
	VERSION_VALUE="custom-url"

	if ! download_file_try "$URL" /tmp/clash.gz "$(detect_proxy)"; then
		write_log "自定义链接下载失败"
		exit 1
	fi

	if ! gunzip -f /tmp/clash.gz; then
		write_log "自定义内核解压失败"
		exit 1
	fi

	if ! install_with_rollback /tmp/clash "$TARGET"; then
		exit 1
	fi
	CORE_INSTALLED=1
	printf '%s\n' "${VERSION_VALUE}" > "$VERSION_FILE"
	touch /usr/share/clashoo/core_down_complete
	write_log "内核更新完成（自定义链接）"
	exit 0
fi

if [ "$CORETYPE" = "4" ] || [ "$CORETYPE" = "5" ]; then
	SINGBOX_ARCH="$(map_singbox_arch "$MODELTYPE")"
	OPENWRT_ARCH="$(detect_openwrt_arch)"
	if [ "$CORETYPE" = "4" ]; then
		write_log "已选择 sing-box 稳定版"
		write_log "正在获取 GitHub Release 信息..."
		TAG=$(fetch_latest_tag "SagerNet/sing-box")
		[ -z "$TAG" ] && write_log "获取 sing-box 稳定版版本号失败" && exit 1
	else
		write_log "已选择 sing-box 预发布版"
		write_log "正在获取 GitHub Release 信息..."
		TAG=$(fetch_prerelease_tag "SagerNet/sing-box")
		[ -z "$TAG" ] && TAG=$(fetch_latest_tag "SagerNet/sing-box")
		[ -z "$TAG" ] && write_log "获取 sing-box 预发布版版本号失败" && exit 1
	fi
	VER="${TAG#v}"
	SINGBOX_TARGET="$(singbox_target_path)"
	installed=0

	if [ -n "$OPENWRT_ARCH" ]; then
		ASSET="sing-box_${VER}_openwrt_${OPENWRT_ARCH}.ipk"
		URL="https://github.com/SagerNet/sing-box/releases/download/${TAG}/${ASSET}"
		write_log "尝试提取 OpenWrt IPK 包: ${ASSET}"
		if download_with_mirrors "$URL" /tmp/singbox-openwrt.ipk raw && install_singbox_openwrt_asset /tmp/singbox-openwrt.ipk "$SINGBOX_TARGET"; then
			installed=1
		else
			write_log "OpenWrt IPK 提取失败，尝试官方 musl tar 包"
		fi
	fi

	if [ "$installed" -ne 1 ]; then
		for ASSET in "sing-box-${VER}-linux-${SINGBOX_ARCH}-musl.tar.gz" "sing-box-${VER}-linux-${SINGBOX_ARCH}.tar.gz"; do
			URL="https://github.com/SagerNet/sing-box/releases/download/${TAG}/${ASSET}"
			write_log "尝试下载 sing-box 归档包: ${ASSET}"
			if download_with_mirrors "$URL" /tmp/singbox.tar.gz gzip && install_singbox_tar_asset /tmp/singbox.tar.gz "$SINGBOX_TARGET"; then
				installed=1
				break
			fi
		done
	fi

	if [ "$installed" -ne 1 ]; then
		write_log "sing-box 下载或安装失败（可能是架构不匹配）"
		exit 1
	fi

	CORE_INSTALLED=1
	# 稳定版与 Alpha 分路径保存，避免互相覆盖；版本文件保持兼容。
	if [ "$CORETYPE" = "4" ]; then
		printf '%s\n' "$TAG" > "/usr/share/clashoo/singbox_stable_version"
	else
		printf '%s\n' "$TAG" > "/usr/share/clashoo/singbox_alpha_version"
	fi
	printf '%s\n' "$TAG" > "/usr/share/clashoo/singbox_version"
	rm -f /tmp/singbox.tar.gz /tmp/singbox-openwrt.ipk
	rm -rf /tmp/singbox-extract /tmp/singbox-openwrt-pkg /tmp/singbox-openwrt-root
	touch /usr/share/clashoo/core_down_complete
	write_log "sing-box 更新完成: $TAG"
	exit 0
fi

if [ "$CORETYPE" = "1" ]; then
	write_log "已选择内核通道：mihomo Smart 版（vernesong fork）"
	TAG="Prerelease-Alpha"
	write_log "正在获取 GitHub Release 信息..."
	ASSET=$(pick_mihomo_asset "vernesong/mihomo" "$TAG" "$(map_mihomo_arch "$MODELTYPE")" "smart")
	if [ -z "$ASSET" ]; then
		ALT_TAG=$(fetch_prerelease_tag "vernesong/mihomo")
		[ -n "$ALT_TAG" ] && TAG="$ALT_TAG"
		ASSET=$(pick_mihomo_asset "vernesong/mihomo" "$TAG" "$(map_mihomo_arch "$MODELTYPE")" "smart")
	fi
	URL="https://github.com/vernesong/mihomo/releases/download/${TAG}/${ASSET}"
	TARGET="/usr/bin/smart"
	VERSION_FILE="/usr/share/clashoo/mihomo_version"
	VERSION_VALUE="smart-$(printf '%s\n' "$ASSET" | sed -n 's#^mihomo-.*-alpha-smart-\([0-9a-fA-F]\{7,\}\)\.gz$#\1#p' | head -n 1)"
	[ "$VERSION_VALUE" = "smart-" ] && VERSION_VALUE="smart-${TAG}"
elif [ "$CORETYPE" = "2" ]; then
	write_log "已选择内核通道：稳定版"
	write_log "正在获取 GitHub Release 信息..."
	TAG=$(fetch_latest_tag "MetaCubeX/mihomo")
	[ -z "$TAG" ] && write_log "获取稳定版版本号失败" && exit 1
	ASSET=$(pick_mihomo_asset "MetaCubeX/mihomo" "$TAG" "$(map_mihomo_arch "$MODELTYPE")" "stable")
	URL="https://github.com/MetaCubeX/mihomo/releases/download/${TAG}/${ASSET}"
	TARGET="/usr/bin/mihomo-stable"
	VERSION_FILE="/usr/share/clashoo/clash_meta_version"
 	VERSION_VALUE="$TAG"
else
	write_log "已选择内核通道：预发布版"
	TAG="Prerelease-Alpha"
	write_log "正在获取 GitHub Release 信息..."
	ASSET=$(pick_mihomo_asset "MetaCubeX/mihomo" "$TAG" "$(map_mihomo_arch "$MODELTYPE")" "alpha")
	[ -z "$ASSET" ] && TAG=$(fetch_prerelease_tag "MetaCubeX/mihomo")
	[ -z "$TAG" ] && TAG=$(fetch_latest_tag "MetaCubeX/mihomo")
	[ -z "$TAG" ] && write_log "获取预发布版本号失败" && exit 1
	[ -z "$ASSET" ] && ASSET=$(pick_mihomo_asset "MetaCubeX/mihomo" "$TAG" "$(map_mihomo_arch "$MODELTYPE")" "alpha")
	[ -z "$ASSET" ] && ASSET=$(pick_mihomo_asset "MetaCubeX/mihomo" "$TAG" "$(map_mihomo_arch "$MODELTYPE")" "stable")
	URL="https://github.com/MetaCubeX/mihomo/releases/download/${TAG}/${ASSET}"
	TARGET="/usr/bin/mihomo"
	VERSION_FILE="/usr/share/clashoo/mihomo_version"
	VERSION_VALUE="$(printf '%s\n' "$ASSET" | sed -n 's#^mihomo-.*-alpha-\([0-9a-fA-F]\{7,\}\)\.gz$#\1#p' | head -n 1)"
	[ -z "$VERSION_VALUE" ] && VERSION_VALUE="$TAG"
fi

if [ -z "$TAG" ]; then
	write_log "内核版本检查失败"
	exit 1
fi

if [ -z "$ASSET" ]; then
	write_log "未找到对应架构的内核文件（${MODELTYPE:-unknown} / ${TAG:-unknown}）"
	exit 1
fi
write_log "版本标签：$TAG"
write_log "匹配内核文件：$ASSET"

if [ -n "$TARGET_DCORE" ] && installed_version_matches "$VERSION_FILE" "$VERSION_VALUE" && verify_binary "$TARGET"; then
	write_log "内核已是最新版本：$VERSION_VALUE"
	exit 0
fi

write_log "开始下载内核"
if ! download_with_mirrors "$URL" /tmp/clash.gz; then
	write_log "内核下载失败：所有镜像源均不可达（已尝试 gh-proxy.com / ghfast.top / 裸 GitHub）"
	write_log "可设置自定义镜像前缀：uci set clashoo.config.core_mirror_prefix='https://your.mirror/' && uci commit clashoo"
	exit 1
fi

if ! gunzip -f /tmp/clash.gz; then
	write_log "内核解压失败"
	exit 1
fi

if ! install_with_rollback /tmp/clash "$TARGET"; then
	exit 1
fi
CORE_INSTALLED=1
printf '%s\n' "${VERSION_VALUE:-$TAG}" > "$VERSION_FILE"
touch /usr/share/clashoo/core_down_complete
write_log "内核更新完成"
